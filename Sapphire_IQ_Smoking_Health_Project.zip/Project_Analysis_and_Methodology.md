# Sapphire IQ | Smoking and Health Analysis

## Project overview
Healthcare analytics project based on the supplied patient-level dataset. The original brief specifies four objectives: patient KPIs, DAX calculated columns, smoking/health indicators, and demographic/health patterns.

## Dataset quality checks
- Rows: 10,000
- Columns in original CSV: 15
- Missing values in original CSV: 0
- Duplicate rows in original CSV: 0
- Unique patient IDs: 10,000
- Diagnosis dates parsed to YYYY-MM-DD in the cleaned export.

## Objective 1 — Overall patient health KPIs
- Total patients: 10,000
- Current smokers: 3,015
- Patients with a recorded organ category: 7,227
- Patients with a recorded health condition: 5,772

A recorded organ/condition count excludes the explicit placeholder values `No Recorded Organ Condition` and `No Diagnosed Condition`.

## Objective 2 — Calculated columns
- Age Group: 18–29, 30–44, 45–59, 60+.
- BP Risk Category: Lower Range, Elevated, High, using the documented rules in `DAX_Calculations.md`.

## Objective 3 — Smoking patterns and health indicators
- Average cigarettes/day among current smokers: 17.11
- Average cholesterol across all records: 196.89 mg/dL.
- Smoking status distribution: {'Never Smoked': 4263, 'Current Smoker': 3015, 'Former Smoker': 2722}
- Average cholesterol by BP category: {'Elevated': 195.73, 'High': 197.81, 'Lower Range': 195.35}

## Objective 4 — Demographics and health patterns
- Current smokers by age group: {'18–29': 508, '30–44': 668, '45–59': 715, '60+': 1124}
- Estimated exposure level distribution: {'None recorded': 6985, 'Low (1–200)': 1577, 'High (400+)': 742, 'Moderate (201–400)': 696}

## Methodology and limitations
1. `Estimated_Exposure_Index = Cigarettes_Per_Day × Years_Smoking`. This is a simple proxy for comparing the supplied fields, not a clinical pack-year measure.
2. Former smokers have 0 recorded cigarettes/day. Their past smoking intensity is not available in this dataset, so the proxy can understate former smokers' historical exposure. Do not interpret their zero index as no lifetime exposure.
3. The BP categories are project-defined analytical bands. The supplied brief gives example labels but no numeric cut-offs. These bands are for visualization only and are not medical classifications or advice.
4. The dataset includes the category `No Diagnosed Condition`; this is treated as no recorded health condition, not proof of perfect health.
5. Results are descriptive and exploratory. They do not establish diagnosis or prove causation between smoking and any health condition.

## Dashboard
Open `Sapphire_IQ_Smoking_Health_Dashboard.html` in a modern browser with internet access (the Plotly chart library is loaded from its public CDN). It contains two pages and filters for region, gender, smoking status, age group, and BP risk category.
