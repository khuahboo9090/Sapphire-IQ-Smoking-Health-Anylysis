# Sapphire IQ — Smoking and Health Analysis

A phone-friendly, interactive web dashboard and supporting analysis files based on the supplied Sapphire IQ project brief and CSV dataset.

## Files
- `Sapphire_IQ_Smoking_Health_Dashboard.html` — two-page interactive dashboard with filters and charts.
- `Smoking_Health_Cleaned.csv` — cleaned dataset with Age Group, BP Risk Category, Estimated Exposure Index, and Estimated Exposure Level.
- `DAX_Calculations.md` — DAX measures and calculated-column formulas for recreating the work in Power BI Desktop.
- `Project_Analysis_and_Methodology.md` — project objectives, data-quality checks, results, methodology, and limitations.

## View the dashboard
Open the HTML file in a browser with internet access. The chart library is loaded from Plotly's CDN.

## GitHub Pages publishing
1. Create a public GitHub repository.
2. Upload all project files. For GitHub Pages, rename/copy the HTML file to `index.html` in the repository root.
3. In repository Settings → Pages, select deploy from the `main` branch and `/ (root)`.
4. Wait for GitHub Pages to publish. Submit the resulting `https://<username>.github.io/<repository>/` URL only after opening it and verifying it works.

## Important distinction
This is an interactive web-dashboard alternative, not a native Power BI `.pbix` file. The DAX reference is included so the analysis can be recreated in Power BI when Desktop is available.

## Analytical limitations
The exposure index is a simple proxy (`Cigarettes_Per_Day × Years_Smoking`), not a clinical pack-year measure. Former smokers have zero recorded cigarettes/day, so historical intensity is unavailable. BP bands are project-defined exploratory categories. See `Project_Analysis_and_Methodology.md`.
