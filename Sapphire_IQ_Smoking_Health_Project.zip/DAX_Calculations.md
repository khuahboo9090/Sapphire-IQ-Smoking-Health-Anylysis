# DAX calculations for the Sapphire IQ Smoking & Health Analysis

Assumed Power BI table name: `Smoking_Health`

## Measures (Objective 1)

```DAX
Total Patients =
DISTINCTCOUNT(Smoking_Health[Patient_ID])

Current Smokers =
CALCULATE(
    DISTINCTCOUNT(Smoking_Health[Patient_ID]),
    Smoking_Health[Smoking_Status] = "Current Smoker"
)

Patients with Recorded Organ =
CALCULATE(
    DISTINCTCOUNT(Smoking_Health[Patient_ID]),
    Smoking_Health[Diagnosed_Organ] <> "No Recorded Organ Condition"
)

Patients with Recorded Health Condition =
CALCULATE(
    DISTINCTCOUNT(Smoking_Health[Patient_ID]),
    Smoking_Health[Health_Condition] <> "No Diagnosed Condition"
)

Average Cigarettes per Day =
AVERAGE(Smoking_Health[Cigarettes_Per_Day])

Average Cholesterol =
AVERAGE(Smoking_Health[Total_Cholesterol_mg_dL])
```

## Calculated columns (Objective 2)

```DAX
Age Group =
SWITCH(
    TRUE(),
    Smoking_Health[Age] <= 29, "18–29",
    Smoking_Health[Age] <= 44, "30–44",
    Smoking_Health[Age] <= 59, "45–59",
    "60+"
)
```

```DAX
BP Risk Category =
VAR S = Smoking_Health[Systolic_BP_mmHg]
VAR D = Smoking_Health[Diastolic_BP_mmHg]
RETURN
    SWITCH(
        TRUE(),
        S >= 130 || D >= 80, "High",
        S >= 120 && S <= 129 && D < 80, "Elevated",
        "Lower Range"
    )
```

## Estimated exposure proxy

```DAX
Estimated Exposure Index =
Smoking_Health[Cigarettes_Per_Day] * Smoking_Health[Years_Smoking]
```

```DAX
Estimated Exposure Level =
SWITCH(
    TRUE(),
    Smoking_Health[Estimated Exposure Index] = 0, "None recorded",
    Smoking_Health[Estimated Exposure Index] <= 200, "Low (1–200)",
    Smoking_Health[Estimated Exposure Index] <= 400, "Moderate (201–400)",
    "High (400+)"
)
```

Important: these are project-specific analytical groupings. The source brief does not specify exact BP thresholds or exposure cut-offs, so the dashboard documents the adopted rules. The exposure index is not a clinical pack-year measure. Former smokers have 0 cigarettes/day in the supplied data, so past intensity cannot be reconstructed.
